package com.lanchat.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.net.ServerSocket
import java.net.Socket

class TCPMessenger(private val port: Int = 8889) {
    private var serverSocket: ServerSocket? = null
    private var isServerRunning = false

    suspend fun startServer(onMessageReceived: (NetworkMessage, String) -> Unit) = withContext(Dispatchers.IO) {
        try {
            serverSocket = ServerSocket(port)
            isServerRunning = true
            while (isServerRunning) {
                val socket = serverSocket?.accept() ?: break
                val senderIp = socket.inetAddress.hostAddress ?: ""
                val ois = ObjectInputStream(socket.getInputStream())
                val message = ois.readObject() as? NetworkMessage
                if (message != null) {
                    onMessageReceived(message, senderIp)
                }
                socket.close()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun sendMessage(targetIp: String, message: NetworkMessage): Boolean = withContext(Dispatchers.IO) {
        try {
            val socket = Socket(targetIp, port)
            val oos = ObjectOutputStream(socket.getOutputStream())
            oos.writeObject(message)
            oos.flush()
            socket.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun stopServer() {
        isServerRunning = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}