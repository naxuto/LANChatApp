package com.lanchat.app.network

import java.io.Serializable

data class Peer(
    val ip: String,
    val name: String,
    val lastSeen: Long = System.currentTimeMillis()
) : Serializable

data class NetworkMessage(
    val id: String,
    val senderName: String,
    val content: String,
    val timestamp: Long
) : Serializable