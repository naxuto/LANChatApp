package com.lanchat.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

class UDPDiscovery(
    private val deviceName: String,
    private val port: Int = 8888
) {
    private var isListening = false

    suspend fun startBroadcasting() = withContext(Dispatchers.IO) {
        try {
            val socket = DatagramSocket()
            socket.broadcast = true
            val message = "LAN_CHAT_DISCOVERY:$deviceName".toByteArray()
            val packet = DatagramPacket(
                message,
                message.size,
                InetAddress.getByName("255.255.255.255"),
                port
            )
            socket.send(packet)
            socket.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    suspend fun startListening(onPeerDiscovered: (Peer) -> Unit) = withContext(Dispatchers.IO) {
        isListening = true
        val socket = DatagramSocket(port)
        val buffer = ByteArray(1024)

        while (isListening) {
            try {
                val packet = DatagramPacket(buffer, buffer.size)
                socket.receive(packet)
                val data = String(packet.data, 0, packet.length)
                if (data.startsWith("LAN_CHAT_DISCOVERY:")) {
                    val peerName = data.removePrefix("LAN_CHAT_DISCOVERY:")
                    val peerIp = packet.address.hostAddress
                    if (peerIp != null) {
                        onPeerDiscovered(Peer(peerIp, peerName))
                    }
                }
            } catch (e: Exception) {
                if (!isListening) break
            }
        }
        socket.close()
    }

    fun stop() {
        isListening = false
    }
}