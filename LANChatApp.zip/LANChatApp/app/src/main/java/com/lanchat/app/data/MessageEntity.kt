package com.lanchat.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val senderIp: String,
    val senderName: String,
    val content: String,
    val timestamp: Long,
    val status: String,
    val isOutgoing: Boolean
)