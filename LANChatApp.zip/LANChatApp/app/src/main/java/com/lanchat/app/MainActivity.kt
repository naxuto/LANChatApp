package com.lanchat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.lanchat.app.data.AppDatabase
import com.lanchat.app.data.MessageEntity
import com.lanchat.app.network.NetworkMessage
import com.lanchat.app.network.TCPMessenger
import com.lanchat.app.network.UDPDiscovery
import com.lanchat.app.ui.ChatScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

class MainActivity : ComponentActivity() {

    private lateinit var db: AppDatabase
    private val tcpMessenger = TCPMessenger()
    private lateinit var udpDiscovery: UDPDiscovery

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        db = AppDatabase.getDatabase(this)
        val deviceName = android.os.Build.MODEL
        udpDiscovery = UDPDiscovery(deviceName)

        // Start Server & Discovery
        lifecycleScope.launch(Dispatchers.IO) {
            tcpMessenger.startServer { networkMessage, senderIp ->
                lifecycleScope.launch(Dispatchers.IO) {
                    db.messageDao().insertMessage(
                        MessageEntity(
                            id = networkMessage.id,
                            senderIp = senderIp,
                            senderName = networkMessage.senderName,
                            content = networkMessage.content,
                            timestamp = networkMessage.timestamp,
                            status = "DELIVERED",
                            isOutgoing = false
                        )
                    )
                }
            }
        }

        lifecycleScope.launch(Dispatchers.IO) {
            udpDiscovery.startBroadcasting()
            udpDiscovery.startListening { peer ->
                // Peer discovered logic can be added here
            }
        }

        setContent {
            MaterialTheme {
                Surface {
                    val messages by db.messageDao().getAllMessages().collectAsState(initial = emptyList())
                    
                    ChatScreen(
                        messages = messages,
                        onSendMessage = { text ->
                            val msgId = UUID.randomUUID().toString()
                            val newMsg = MessageEntity(
                                id = msgId,
                                senderIp = "127.0.0.1",
                                senderName = "Me",
                                content = text,
                                timestamp = System.currentTimeMillis(),
                                status = "SENT",
                                isOutgoing = true
                            )
                            lifecycleScope.launch(Dispatchers.IO) {
                                db.messageDao().insertMessage(newMsg)
                                // Broadcast or send via TCP to specific peers
                            }
                        }
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        tcpMessenger.stopServer()
        udpDiscovery.stop()
    }
}